package dev.macelimit;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.block.ShulkerBox;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.CrafterCraftEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.EntityRemoveEvent;
import org.bukkit.event.entity.ItemSpawnEvent;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryMoveItemEvent;
import org.bukkit.event.inventory.InventoryPickupItemEvent;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.event.inventory.PrepareGrindstoneEvent;
import org.bukkit.event.player.PlayerItemBreakEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BlockStateMeta;
import org.bukkit.inventory.meta.BundleMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;
import java.util.UUID;
import java.util.function.Consumer;

/**
 * MaceLimit: на сервере может существовать не больше N булав (по умолчанию 5).
 * Каждая скрафченная булава получает скрытую метку (номер + уникальный ключ).
 * Слот освобождается ТОЛЬКО по явному сигналу игры (деспавн, урон, поломка)
 * или вручную оператором: /mace release <номер>.
 */
public final class MaceLimit extends JavaPlugin implements Listener, TabExecutor {

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();
    private static final DateTimeFormatter DATE =
            DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm").withZone(ZoneId.systemDefault());

    private enum State { PLAYER, GROUND, CONTAINER, UNKNOWN }

    private static final class Rec {
        final int id;
        final UUID uid;
        State state = State.UNKNOWN;
        String holderName;      // последний известный владелец
        UUID holderUuid;
        String world;
        double x, y, z;
        long lastSeen;
        String craftedBy;
        long craftedAt;

        Rec(int id, UUID uid) {
            this.id = id;
            this.uid = uid;
        }
    }

    private final Map<Integer, Rec> recs = new TreeMap<>();
    private NamespacedKey keyId;
    private NamespacedKey keyUid;
    private File dataFile;
    private boolean dirty;

    // ------------------------------------------------------------ жизненный цикл

    @Override
    public void onEnable() {
        saveDefaultConfig();
        keyId = new NamespacedKey(this, "mace_id");
        keyUid = new NamespacedKey(this, "mace_uid");
        dataFile = new File(getDataFolder(), "maces.yml");
        load();

        Bukkit.getPluginManager().registerEvents(this, this);
        var cmd = getCommand("mace");
        if (cmd != null) {
            cmd.setExecutor(this);
            cmd.setTabCompleter(this);
        }

        long period = Math.max(1, getConfig().getLong("scan-seconds", 5)) * 20L;
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            for (Player p : Bukkit.getOnlinePlayers()) scanPlayer(p);
            if (dirty) save();
        }, 100L, period);
    }

    @Override
    public void onDisable() {
        save();
    }

    private int limit() {
        return Math.max(1, getConfig().getInt("limit", 5));
    }

    // ------------------------------------------------------------------ крафт

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onCraft(CraftItemEvent e) {
        ItemStack current = e.getCurrentItem();
        if (current == null || current.getType() != Material.MACE) return;
        if (!(e.getWhoClicked() instanceof Player p)) return;

        int slot = freeSlot();
        if (slot == -1) {
            e.setCancelled(true);
            denyFull(p);
            return;
        }
        if (e.isShiftClick()) {
            e.setCancelled(true);
            p.sendMessage(msg("shift-click"));
            return;
        }

        UUID uid = UUID.randomUUID();
        e.setCurrentItem(mark(current, slot, uid));

        Rec r = new Rec(slot, uid);
        r.craftedBy = p.getName();
        r.craftedAt = System.currentTimeMillis();
        recs.put(slot, r);
        setPlayer(r, p);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onCrafter(CrafterCraftEvent e) {
        ItemStack result = e.getResult();
        if (result.getType() != Material.MACE) return;

        int slot = freeSlot();
        if (slot == -1) {
            e.setCancelled(true);
            return;
        }
        UUID uid = UUID.randomUUID();
        e.setResult(mark(result, slot, uid));

        Rec r = new Rec(slot, uid);
        r.craftedBy = "Крафтер";
        r.craftedAt = System.currentTimeMillis();
        recs.put(slot, r);
        setAt(r, State.CONTAINER, e.getBlock().getLocation());
    }

    private void denyFull(Player p) {
        String limit = String.valueOf(limit());
        p.showTitle(Title.title(
                LEGACY.deserialize(raw("limit-title").replace("{limit}", limit)),
                LEGACY.deserialize(raw("limit-subtitle").replace("{limit}", limit))));
        p.sendMessage(LEGACY.deserialize(raw("limit-chat").replace("{limit}", limit)));
    }

    /** Нельзя склеивать две отмеченные булавы в наковальне/точиле, иначе один номер потеряется. */
    @EventHandler
    public void onAnvil(PrepareAnvilEvent e) {
        ItemStack a = e.getInventory().getFirstItem();
        ItemStack b = e.getInventory().getSecondItem();
        if (isTagged(a) && isTagged(b)) e.setResult(null);
    }

    @EventHandler
    public void onGrindstone(PrepareGrindstoneEvent e) {
        ItemStack a = e.getInventory().getUpperItem();
        ItemStack b = e.getInventory().getLowerItem();
        if (isTagged(a) && isTagged(b)) e.setResult(null);
    }

    // ------------------------------------------------- отслеживание положения

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        scanPlayer(e.getPlayer());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        scanPlayer(e.getPlayer());
    }

    @EventHandler(ignoreCancelled = true)
    public void onPickup(EntityPickupItemEvent e) {
        if (e.getEntity() instanceof Player p) {
            visit(e.getItem().getItemStack(), r -> setPlayer(r, p));
        }
    }

    @EventHandler
    public void onItemSpawn(ItemSpawnEvent e) {
        Location loc = e.getLocation();
        visit(e.getEntity().getItemStack(), r -> setAt(r, State.GROUND, loc));
    }

    @EventHandler(ignoreCancelled = true)
    public void onHopperPickup(InventoryPickupItemEvent e) {
        Location loc = e.getInventory().getLocation();
        if (loc == null) return;
        visit(e.getItem().getItemStack(), r -> setAt(r, State.CONTAINER, loc));
    }

    @EventHandler(ignoreCancelled = true)
    public void onMove(InventoryMoveItemEvent e) {
        Location loc = e.getDestination().getLocation();
        if (loc == null) return;
        visit(e.getItem(), r -> setAt(r, State.CONTAINER, loc));
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        Inventory top = e.getInventory();
        Location loc = top.getLocation();
        if (loc != null && !(top.getHolder() instanceof Player)) {
            for (ItemStack it : top.getContents()) {
                visit(it, r -> setAt(r, State.CONTAINER, loc));
            }
        }
        if (e.getPlayer() instanceof Player p) scanPlayer(p);
    }

    // ------------------------------------- освобождение слота (только по сигналу игры)

    @EventHandler(priority = EventPriority.MONITOR)
    public void onEntityRemove(EntityRemoveEvent e) {
        if (!(e.getEntity() instanceof Item item)) return;
        EntityRemoveEvent.Cause cause = e.getCause();
        // Только явные сигналы: деспавн, гибель предмета (лава, огонь, кактус, взрыв), вылет из мира.
        // UNLOAD, PICKUP, PLAYER_QUIT и всё остальное слот НЕ освобождают.
        if (cause != EntityRemoveEvent.Cause.DESPAWN
                && cause != EntityRemoveEvent.Cause.DEATH
                && cause != EntityRemoveEvent.Cause.OUT_OF_WORLD) {
            return;
        }
        visit(item.getItemStack(), this::free);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onBreak(PlayerItemBreakEvent e) {
        visit(e.getBrokenItem(), this::free);
    }

    private void free(Rec r) {
        recs.remove(r.id);
        dirty = true;
        getLogger().info("Булава #" + r.id + " уничтожена, слот освобождён.");
    }

    // --------------------------------------------------------------- сканирование

    private void scanPlayer(Player p) {
        ItemStack[] contents = p.getInventory().getContents();
        for (int i = 0; i < contents.length; i++) {
            ItemStack it = contents[i];
            if (it == null) continue;
            if (it.getType() == Material.MACE) {
                Rec r = recFor(it);
                if (r != null) {
                    setPlayer(r, p);
                } else if (isTagged(it)) {
                    // «воскресшая» булава, чей номер уже занят другой булавой
                    p.getInventory().setItem(i, null);
                    p.sendMessage(msg("ghost"));
                }
            } else {
                visit(it, r -> setPlayer(r, p));
            }
        }
        for (ItemStack it : p.getEnderChest().getContents()) {
            visit(it, r -> setPlayer(r, p));
        }
    }

    private void visit(ItemStack it, Consumer<Rec> action) {
        visit(it, action, 0);
    }

    private void visit(ItemStack it, Consumer<Rec> action, int depth) {
        if (it == null || depth > 3) return;
        Material t = it.getType();
        if (t == Material.MACE) {
            Rec r = recFor(it);
            if (r != null) action.accept(r);
            return;
        }
        String n = t.name();
        if (!(n.endsWith("SHULKER_BOX") || n.contains("BUNDLE")) || !it.hasItemMeta()) return;

        ItemMeta meta = it.getItemMeta();
        if (meta instanceof BlockStateMeta bsm && bsm.getBlockState() instanceof ShulkerBox box) {
            for (ItemStack in : box.getInventory().getContents()) visit(in, action, depth + 1);
        } else if (meta instanceof BundleMeta bm) {
            for (ItemStack in : bm.getItems()) visit(in, action, depth + 1);
        }
    }

    // ------------------------------------------------------------------- метки

    private ItemStack mark(ItemStack base, int id, UUID uid) {
        ItemStack out = base.clone();
        ItemMeta meta = out.getItemMeta();
        meta.getPersistentDataContainer().set(keyId, PersistentDataType.INTEGER, id);
        meta.getPersistentDataContainer().set(keyUid, PersistentDataType.STRING, uid.toString());
        out.setItemMeta(meta);
        return out;
    }

    private boolean isTagged(ItemStack it) {
        return it != null && it.getType() == Material.MACE && it.hasItemMeta()
                && it.getItemMeta().getPersistentDataContainer().has(keyId, PersistentDataType.INTEGER);
    }

    /**
     * Запись, соответствующая булаве.
     * null - булава без метки (например из /give) или «призрак» (её номер занят другой булавой).
     * Если номер булавы свободен (её ошибочно освободили), она возвращается на свой номер.
     */
    private Rec recFor(ItemStack it) {
        if (!isTagged(it)) return null;
        var pdc = it.getItemMeta().getPersistentDataContainer();
        Integer id = pdc.get(keyId, PersistentDataType.INTEGER);
        String uidStr = pdc.get(keyUid, PersistentDataType.STRING);
        if (id == null || uidStr == null) return null;

        UUID uid;
        try {
            uid = UUID.fromString(uidStr);
        } catch (IllegalArgumentException ex) {
            return null;
        }

        Rec r = recs.get(id);
        if (r != null) return r.uid.equals(uid) ? r : null;

        if (id >= 1 && id <= limit()) {
            Rec restored = new Rec(id, uid);
            restored.craftedBy = "восстановлена";
            restored.craftedAt = System.currentTimeMillis();
            recs.put(id, restored);
            dirty = true;
            return restored;
        }
        return null;
    }

    private int freeSlot() {
        for (int i = 1; i <= limit(); i++) {
            if (!recs.containsKey(i)) return i;
        }
        return -1;
    }

    private void setPlayer(Rec r, Player p) {
        r.state = State.PLAYER;
        r.holderName = p.getName();
        r.holderUuid = p.getUniqueId();
        r.lastSeen = System.currentTimeMillis();
        dirty = true;
    }

    private void setAt(Rec r, State s, Location loc) {
        r.state = s;
        if (loc != null && loc.getWorld() != null) {
            r.world = loc.getWorld().getName();
            r.x = loc.getX();
            r.y = loc.getY();
            r.z = loc.getZ();
        }
        r.lastSeen = System.currentTimeMillis();
        dirty = true;
    }

    // ---------------------------------------------------------------- команды

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        if (a.length == 0) {
            reply(s, "&eИспользование: /mace list" + (s.hasPermission("mace.admin")
                    ? " [ex] | /mace release <номер> | /mace reload" : ""));
            return true;
        }
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "list" -> {
                boolean ex = a.length >= 2 && a[1].equalsIgnoreCase("ex");
                if (ex && !s.hasPermission("mace.admin")) {
                    reply(s, "&cНет прав.");
                    return true;
                }
                sendList(s, ex);
            }
            case "release" -> {
                if (!s.hasPermission("mace.admin")) { reply(s, "&cНет прав."); return true; }
                if (a.length != 2) { reply(s, "&eИспользование: /mace release <номер>"); return true; }
                int n;
                try {
                    n = Integer.parseInt(a[1]);
                } catch (NumberFormatException ex) {
                    reply(s, "&cНомер должен быть числом.");
                    return true;
                }
                if (recs.remove(n) != null) {
                    dirty = true;
                    save();
                    reply(s, "&aСлот #" + n + " освобождён. Можно крафтить новую булаву.");
                } else {
                    reply(s, "&eСлот #" + n + " уже свободен или не существует.");
                }
            }
            case "reload" -> {
                if (!s.hasPermission("mace.admin")) { reply(s, "&cНет прав."); return true; }
                reloadConfig();
                reply(s, "&aКонфиг перезагружен.");
            }
            default -> reply(s, "&eИспользование: /mace list");
        }
        return true;
    }

    private void sendList(CommandSender s, boolean ex) {
        int limit = limit();
        reply(s, "&6Булавы (" + recs.size() + " из " + limit + " существуют)" + (ex ? " &7[подробно]" : "") + ":");

        for (int i = 1; i <= limit; i++) {
            Rec r = recs.get(i);
            if (r == null) {
                reply(s, "&7#" + i + " не создана");
                continue;
            }
            if (!ex) {
                String where = switch (r.state) {
                    case PLAYER -> "у игрока &f" + r.holderName;
                    case GROUND -> "на земле";
                    case CONTAINER -> "в контейнере";
                    case UNKNOWN -> "местонахождение неизвестно";
                };
                reply(s, "&e#" + i + " &7" + where);
                continue;
            }

            StringBuilder sb = new StringBuilder("&e#" + i + " &7");
            switch (r.state) {
                case PLAYER -> {
                    boolean online = r.holderUuid != null && Bukkit.getPlayer(r.holderUuid) != null;
                    sb.append("у игрока &f").append(r.holderName).append("&7 (")
                            .append(online ? "онлайн" : "оффлайн").append(")");
                }
                case GROUND -> sb.append("на земле");
                case CONTAINER -> sb.append("в контейнере");
                case UNKNOWN -> sb.append("местонахождение неизвестно");
            }
            if (r.lastSeen > 0) sb.append(", видели ").append(ago(r.lastSeen));
            if (r.state != State.PLAYER && r.world != null) {
                sb.append(", ").append(r.world).append(" x").append((int) r.x)
                        .append(" y").append((int) r.y).append(" z").append((int) r.z);
            }
            if (r.state != State.PLAYER && r.holderName != null) {
                sb.append(", последний владелец ").append(r.holderName);
            }
            sb.append(", скрафтил ").append(r.craftedBy == null ? "?" : r.craftedBy);
            if (r.craftedAt > 0) sb.append(" ").append(DATE.format(Instant.ofEpochMilli(r.craftedAt)));
            reply(s, sb.toString());
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String label, String[] a) {
        boolean admin = s.hasPermission("mace.admin");
        List<String> out = new ArrayList<>();
        if (a.length == 1) {
            out.add("list");
            if (admin) { out.add("release"); out.add("reload"); }
        } else if (a.length == 2 && admin) {
            if (a[0].equalsIgnoreCase("list")) out.add("ex");
            if (a[0].equalsIgnoreCase("release")) {
                for (int id : recs.keySet()) out.add(String.valueOf(id));
            }
        }
        String prefix = a.length == 0 ? "" : a[a.length - 1].toLowerCase(Locale.ROOT);
        out.removeIf(x -> !x.toLowerCase(Locale.ROOT).startsWith(prefix));
        return out;
    }

    // ------------------------------------------------------------------ хранение

    private void load() {
        recs.clear();
        if (!dataFile.exists()) return;
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(dataFile);
        ConfigurationSection sec = yaml.getConfigurationSection("maces");
        if (sec == null) return;
        for (String key : sec.getKeys(false)) {
            ConfigurationSection m = sec.getConfigurationSection(key);
            if (m == null) continue;
            try {
                int id = Integer.parseInt(key);
                Rec r = new Rec(id, UUID.fromString(m.getString("uid", "")));
                r.state = State.valueOf(m.getString("state", "UNKNOWN"));
                r.holderName = m.getString("holder-name");
                String hu = m.getString("holder-uuid");
                if (hu != null) r.holderUuid = UUID.fromString(hu);
                r.world = m.getString("world");
                r.x = m.getDouble("x");
                r.y = m.getDouble("y");
                r.z = m.getDouble("z");
                r.lastSeen = m.getLong("last-seen");
                r.craftedBy = m.getString("crafted-by");
                r.craftedAt = m.getLong("crafted-at");
                recs.put(id, r);
            } catch (IllegalArgumentException ex) {
                getLogger().warning("Пропущена повреждённая запись булавы #" + key);
            }
        }
    }

    private synchronized void save() {
        YamlConfiguration yaml = new YamlConfiguration();
        for (Rec r : recs.values()) {
            String p = "maces." + r.id + ".";
            yaml.set(p + "uid", r.uid.toString());
            yaml.set(p + "state", r.state.name());
            yaml.set(p + "holder-name", r.holderName);
            yaml.set(p + "holder-uuid", r.holderUuid == null ? null : r.holderUuid.toString());
            yaml.set(p + "world", r.world);
            yaml.set(p + "x", r.x);
            yaml.set(p + "y", r.y);
            yaml.set(p + "z", r.z);
            yaml.set(p + "last-seen", r.lastSeen);
            yaml.set(p + "crafted-by", r.craftedBy);
            yaml.set(p + "crafted-at", r.craftedAt);
        }
        try {
            getDataFolder().mkdirs();
            yaml.save(dataFile);
            dirty = false;
        } catch (IOException e) {
            getLogger().severe("Не удалось сохранить maces.yml: " + e.getMessage());
        }
    }

    // ------------------------------------------------------------------ утилиты

    private String raw(String key) {
        return getConfig().getString("messages." + key, "");
    }

    private Component msg(String key) {
        return LEGACY.deserialize(raw(key));
    }

    private void reply(CommandSender s, String legacy) {
        s.sendMessage(LEGACY.deserialize(legacy));
    }

    private static String ago(long ts) {
        long sec = Math.max(0, (System.currentTimeMillis() - ts) / 1000);
        if (sec < 60) return sec + " сек. назад";
        long min = sec / 60;
        if (min < 60) return min + " мин. назад";
        long h = min / 60;
        if (h < 48) return h + " ч. назад";
        return (h / 24) + " дн. назад";
    }
}
